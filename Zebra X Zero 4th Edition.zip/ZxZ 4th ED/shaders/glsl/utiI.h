#define enableMaps

bool uw(vec4 abt){
if(abt.b > abt.r*2.5 &&  abt.b*3.0 > abt.g){
return true; } else { return false; } }

float ac(float x) {
float A = 3.5;
float B = 0.05;
float C = 3.55;
float D = 3.85;
float E = 0.05;
float F = 0.35;
return ((x * (A * x + C * B) + D * E) / (x * (A * x + B) + D * F)) - E / F;
}

vec3 Hyra(vec3 clr) {
float W = 1.3 / 1.0;
#ifdef enableMaps
float Luma = dot(clr, vec3(0.0, 0.3, 0.3));
vec3 Chroma = clr - Luma;
clr = (Chroma * 1.70) + Luma;
clr = vec3(ac(clr.r), ac(clr.g), ac(clr.b)) / ac(W);
#endif
return clr;
}